# Incremental implementation checklist

Work top to bottom. Each milestone should leave the app buildable and end with a short review note. Do not mark a box done without evidence. The first milestone can be adjusted after repository inspection.

## 0. Repository and build baseline
- [ ] Inspect repository, nested `AGENTS.md`, current branch/status, toolchain, GPUI/GPUI Kit versions, and existing build/run/check commands.
- [ ] Record platform target, minimum macOS version, async runtime, persistence strategy, and known environment limits in a short decision note.
- [ ] Build and launch the existing baseline if a project exists; record exact outcome. If no app exists, create the smallest buildable GPUI shell.
- [ ] Confirm pinned GPUI and GPUI Kit APIs from docs/examples and ensure dependency versions are compatible.

## 1. Window shell and two-pane interaction
- [ ] Establish theme tokens for dense rows, typography, spacing, borders, selection, hover, and active focus.
- [ ] Compose compact top bar, hideable sidebar, resizable two-pane workspace, and bottom status area.
- [ ] Give each pane a visible active/inactive focus state and route a small set of actions to the active pane.
- [ ] Add placeholder tabs and path bars for both panes; keep pane state independent.
- [ ] Verify layout at narrow and wide window sizes and keyboard focus order in the rendered app.

## 2. Local filesystem browsing
- [ ] Define app-owned provider/domain types and typed errors.
- [ ] Implement the local filesystem provider and capability reporting.
- [ ] List directory entries asynchronously; sort directories/files predictably and handle hidden files according to a clear preference.
- [ ] Render name, kind, size, and modified time with loading, empty, permission-denied, and error states.
- [ ] Add row selection, multi-selection, open-folder behavior, and path/breadcrumb navigation.
- [ ] Prevent stale listing responses from replacing a more recent location.
- [ ] Verify against a test fixture folder containing empty directories, hidden files, Unicode names, large files, and inaccessible entries when available.

## 3. Navigation, tabs, favorites, and commands
- [ ] Implement independent back/forward history in each pane.
- [ ] Implement add, activate, close, and reorder tabs per pane.
- [ ] Add favorites in the sidebar and navigate into the selected pane.
- [ ] Add editable location/path entry with validation and clear errors.
- [ ] Add command palette search for implemented actions and locations.
- [ ] Add keybindings for pane focus, navigation, tab actions, selection, and command palette; show bindings in UI.
- [ ] Persist non-secret favorites and workspace preferences; handle corrupt or older settings safely.

## 4. Safe local file operations and transfer queue
- [ ] Define operation plans and destination conflict decisions.
- [ ] Implement create folder, rename, copy, move, and delete with explicit confirmation where needed.
- [ ] Implement bounded transfer scheduling, progress, cancellation, and typed failure reporting.
- [ ] Ensure cross-volume move copies and verifies before source deletion; preserve partial-failure details.
- [ ] Add overwrite/keep-both/skip/cancel decisions and batch application where safe.
- [ ] Build transfer drawer with queued, running, completed, and failed views; expose aggregate status in status bar.
- [ ] Verify interrupted, cancelled, conflicting, and partial transfer outcomes using safe temporary fixtures.

## 5. macOS interaction and visual polish
- [ ] Add native open/save dialogs or equivalent for relevant actions.
- [ ] Add open-in-default-app action with explicit user initiation.
- [ ] Add drag/drop between panes and external app surfaces where supported; communicate copy/move semantics.
- [ ] Add volume roots and access-denied handling; evaluate sandbox/bookmark requirements.
- [ ] Check VoiceOver labels, focus visibility, shortcut discoverability, and reduced-motion behavior where applicable.
- [ ] Review the actual rendered app against the written design brief and attached reference screenshots if supplied to the coding environment.
- [ ] Verify packaging and launch on the intended macOS architecture; document unverified hardware/OS behavior.

## 6. Remote provider preparation and SFTP
- [ ] Re-check maintained Rust SFTP options, license, async runtime compatibility, host-key support, and platform constraints before choosing a crate.
- [ ] Define non-secret connection metadata and OS credential-store adapter; keep secret references out of logs/settings.
- [ ] Implement add/edit/remove/test connection flow with Keychain-backed secret storage and missing-secret recovery.
- [ ] Implement known-host storage, first-connect fingerprint confirmation, changed-key rejection, and explicit recovery.
- [ ] Implement SFTP list/stat/read/write/rename/delete according to advertised capabilities.
- [ ] Verify remote browsing and transfer behavior against a disposable test server; record provider/library versions and gaps.

## 7. FTP and S3 decision and implementation
- [ ] Decide whether plain FTP is acceptable; evaluate FTPS support and clearly communicate transport security limitations.
- [ ] Re-evaluate S3 as object storage: prefixes, pagination, versioning, delete markers, multipart uploads, and no directory/rename equivalence.
- [ ] Add only provider features that have a concrete UX and error model.
- [ ] Store access keys through OS credential storage or supported identity flow; never in plaintext app settings.
- [ ] Verify pagination, retries, cancellation, conflicts, and partial transfers against a disposable account/bucket.

## 8. Release readiness
- [ ] Review architecture boundaries, capability fallbacks, error redaction, and destructive-action confirmations.
- [ ] Check large-directory responsiveness and memory use; virtualize only where measurements justify it.
- [ ] Review keyboard-only usage and all keybindings for conflicts/platform conventions.
- [ ] Verify clean build/package and launch from a clean user-facing install location.
- [ ] Update README, release notes, and this checklist with evidence and remaining limitations.
