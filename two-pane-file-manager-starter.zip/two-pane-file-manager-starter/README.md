# Two-pane Rust file manager starter pack

Copy these files into the root of the application repository, then start Codex CLI there with the contents of `START.md`.

- `AGENTS.md` — durable project rules and Codex workflow.
- `SPEC.md` — product, architecture, provider, transfer, security, and phased MVP design.
- `CHECKLIST.md` — ordered, evidence-based implementation milestones.
- `ORCHESTRATION.md` — optional multi-agent roles, ownership, gates, and CLI workflow.
- `START.md` — resumable master prompt.

The source discussion named GPUI Kit; its current component guide lists building blocks including Sidebar, Resizable, StatusBar, Toolbar, Command, Dock, Tabs, Tree, and VirtualList: https://gpui-kit.com/component/. Confirm APIs against the version pinned in the actual project.
