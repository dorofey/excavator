# Product and architecture specification

## Product
A native-feeling desktop file manager for people who move and organize files across local folders and remote storage. Its core is a ForkLift-style two-pane workspace with Zed-like visual restraint, keyboard navigation, command discovery, and clear focus.

The initial target is macOS, while keeping provider and UI boundaries portable where GPUI supports them. Screenshots referenced in the planning conversation were not available to the starter-pack author; treat the written brief as the design source and add screenshots to the repo later if pixel-level review is wanted.

## Experience and layout
- Global compact top bar: navigation/back-forward, location or focused-pane path, search/command entry, and app-level actions.
- Persistent, hideable sidebar: Favorites, local volumes/locations, and named remote connections. Favorites are shortcuts, not a second file tree.
- Main workspace: two independently navigable panes with a draggable divider. Each pane has its own tabs, breadcrumb/path field, back/forward history, listing, sort, selection, and active-pane state.
- Listing: dense table/list with name, kind, size, modified time; sortable columns, multi-select, inline loading/empty/error states, and virtualization when measured data size warrants it.
- Bottom status bar: active location, selected item count/size, provider state, and transfer summary. Expand it into a transfer drawer for queued/running/completed/failed jobs.
- Command palette: search actions and locations, show keybindings, and invoke pane, file, transfer, favorite, and connection actions.
- Drag/drop: files between panes and external app surfaces when the platform API permits. Make the operation explicit; default to copy for ambiguous cross-provider drops. Keep keyboard/menu alternatives.

## MVP definition
MVP is local filesystem only. It must launch into two useful panes, navigate folders, show metadata, select files, open folders, create folders, rename, copy, move, and delete with confirmation; support tabs/history, favorites, keyboard commands, and a visible transfer queue. Treat cross-volume move as copy then delete only after a verified copy; surface partial failures and offer recovery information. SFTP/FTP/S3 are later phases.

## State and component model
Suggested modules (adapt to the repository, do not create empty scaffolding for all of these upfront):

- `app`: application startup, window composition, global actions and settings.
- `workspace`: sidebar, split layout, pane identity and active-pane routing.
- `pane`: tabs and per-tab browser state.
- `browser`: listing model, selection, sort, path editing and navigation history.
- `domain`: `Location`, `Entry`, `EntryId`, `Metadata`, `ProviderId`, typed errors, operation capabilities.
- `providers`: `FileSystem` trait and local implementation; later remote adapters.
- `transfers`: job model, planner, bounded scheduler, progress events, cancellation and conflict decisions.
- `credentials`: secret references and OS credential-store adapter.
- `persistence`: non-secret preferences, sidebar, favorites, connections and workspace state.

Suggested state ownership:
- `AppState`: sidebar visibility, palette/dialog state, transfer drawer visibility, preferences, provider registry.
- `WorkspaceState`: left/right pane IDs, active pane, divider position.
- `PaneState`: ordered tabs and active tab.
- `TabState`: location, history stack/cursor, listing request generation, entries, selection, sort, loading/error state.
- `TransferManager`: jobs and bounded workers, independent of views; UI subscribes to snapshots/events.

Use stable app-owned IDs. A late listing response must not overwrite a newer navigation: associate requests with a generation/token and discard stale results. GPUI entities should own UI state; pass snapshots/IDs to background work and deliver results back through documented GPUI update mechanisms. Confirm exact APIs against pinned GPUI/GPUI Kit versions.

## Provider boundary
Own a trait along these lines, adapting signatures to the chosen async runtime and GPUI integration:

```rust
trait FileSystem: Send + Sync {
    fn provider_id(&self) -> ProviderId;
    fn capabilities(&self) -> Capabilities;
    async fn list(&self, location: &Location, options: ListOptions) -> Result<Page<Entry>, FsError>;
    async fn metadata(&self, location: &Location) -> Result<Metadata, FsError>;
    async fn create_dir(&self, location: &Location) -> Result<(), FsError>;
    async fn rename(&self, from: &Location, to: &Location) -> Result<(), FsError>;
    async fn delete(&self, location: &Location, kind: DeleteKind) -> Result<(), FsError>;
    async fn open_read(&self, location: &Location) -> Result<Box<dyn AsyncRead + Unpin + Send>, FsError>;
    async fn create_write(&self, location: &Location, mode: WriteMode) -> Result<Box<dyn AsyncWrite + Unpin + Send>, FsError>;
}
```

This is illustrative, not a required compile-ready trait. In Rust, async trait object support/runtime bounds need an explicit dependency decision; use boxed futures or an established compatible pattern if necessary. Avoid pretending one universal path string works for local paths, SFTP paths, and S3 bucket/key locations. Capabilities must report rename, server-side copy, trash, permissions, symlinks, seek, and resumability where relevant. Surface unsupported operations plainly.

A provider registry maps `ProviderId` to implementations and constructs typed `Location`s. Start with `LocalFileSystem`; keep app code unaware of OS-specific file handles except within provider/platform adapters.

## Connections and credentials
Connection records contain a stable ID, display name, provider type, non-secret endpoint/region/user metadata, and a credential reference. Secrets live in macOS Keychain (and a future platform adapter), not the settings file. Support missing/locked credentials as normal states. Never persist passwords/private key contents in logs, errors, clipboard, or plain configuration. Private-key file paths may be metadata, but the key material remains owned by the OS/user. The connection editor should validate endpoints without exposing secrets.

## Transfers and concurrency
A transfer job includes ID, operation, source and destination locations, state, byte/item totals when known, current item, progress, cancellation token, conflict policy, timestamps, and typed failure details. Plan transfers through provider capabilities: server-side copy when safely available; otherwise stream through bounded buffers. Limit concurrent jobs and per-job files/streams. Support pause only if the underlying operation can be paused safely; otherwise do not show a fake pause control. Cancellation must stop scheduling new work and interrupt current I/O when supported. For move across providers, verify destination completion before deleting source. Keep a transfer journal sufficient to explain partial completion and retry safely; never claim global atomicity across providers.

Conflict decisions include replace, keep both, skip, and cancel, with batch application where safe. Preserve metadata only where the destination supports it. Progress events should be throttled for UI responsiveness.

## Security and destructive behavior
- Local root/jail behavior is not implied. Resolve symlinks and permissions according to OS behavior; avoid custom path concatenation that can escape a chosen destination.
- Confirm recursive deletes and overwrites with item/path context. Prefer platform trash where available; clearly distinguish permanent deletion.
- Do not execute/open unknown files automatically. Opening uses explicit user action and platform launch APIs.
- Sanitize error display and redact secrets/credentials from diagnostics.
- Remote host key verification for SFTP must be explicit and persistent; never silently trust changed host keys.
- TLS and endpoint validation must be enabled for supported protocols; do not downgrade silently.
- Consider OS sandbox/file access entitlements and bookmark/access-token persistence during macOS integration; document capability limits.

## Dependency and design-system policy
Before adding a crate, inspect current GPUI and GPUI Kit documentation, compatibility, license, maintenance, async runtime fit, and macOS behavior. Pin compatible versions in the actual project. GPUI Kit currently documents components such as Sidebar, Resizable, StatusBar, Toolbar, Command, Dock, Tabs, Tree, and VirtualList; use only where their APIs suit this product and the pinned version. Avoid adding a second component library or duplicate GPUI version without dependency-tree evidence. See [GPUI Kit components](https://gpui-kit.com/component/).

## Phases
1. **Foundation:** repo inspection, buildable GPUI shell, theme tokens, two-pane layout, active-pane focus, app actions.
2. **Local browsing:** provider contract + local provider, async listings, path entry/breadcrumbs, metadata columns, selection/sort, loading/empty/error states.
3. **Navigation and preferences:** tabs per pane, independent history, favorites, persistence for non-secret settings, command palette/keybindings.
4. **Local operations:** create/rename/copy/move/delete, confirmations, bounded transfer queue, progress/cancel/conflicts, partial-failure reporting.
5. **Polish and macOS integration:** drag/drop, volumes, native dialogs/open-in-default-app, accessibility, packaging, visual/performance review.
6. **SFTP:** authenticated connection flow, host-key verification, credential references, remote browsing and streaming transfers.
7. **FTP/S3:** add only after explicit product prioritization; FTP security limitations and S3 object semantics must be explained in UI and tests. Consider whether FTPS is required instead of plain FTP.

## Acceptance principles
A milestone is complete only when its behavior is implemented and checks are recorded. Compilation is not proof of visual layout, drag/drop, Keychain, host-key, or real remote-provider behavior. Use manual verification notes for OS/UI integration and provider-backed checks where available. Do not add tests unless asked by the user; if the repo's existing workflow already requires tests or a milestone calls for checks, follow that project's instructions and distinguish added tests from executed existing checks.
